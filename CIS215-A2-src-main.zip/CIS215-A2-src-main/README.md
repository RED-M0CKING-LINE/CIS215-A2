# What is this?
This is a class project. It is a trip tracking system made with python with a goal of being crossplatform. The Instructions for the assignment are below:

Perform the following:

1. Write the front end (using any method you're comfortable with) that utilizes a database to store information about trips, vehicles, passengers, and drivers.

    The trip information should be:  Date, destination, start time, arrival time, return date, return start time, return arrival time. 
    
    Vehicle information should be:  Starting mileage, ending mileage, fuel level, starting condition of vehicle, ending condition of vehicle, any reported issues, destination, reason for trip. 

    Passenger information should be: Full name, dob, address. 
    
    Driver information should be:  Full name, dob, address, driver's license number.
    
2. The database should trigger and set an additional hidden vehicle table boolean field called oil_change_needed to TRUE for every 4000 miles.
    
3. Include the ability to query for pertinent information such as:  Which trips a certain driver took and which passengers were present.


# Backend structure:

Since this application is not actually being implemented in the real world, my setup is not overly complicated.

I have a MySQL Database server running on a Rocky Linux VM on my machine. 

This VM was setup for a previous assignment and I have not done any favors to the security of it. (trash passwords, disabled firewall, etc)

The Database schema looks like [this](https://dbdesigner.page.link/aqUSoqe8Foytkd198)
 
# Current oversights in project:

- The front end does not allow any way in which to give a car an oil change, though the trigger does work

- There is no way to link passengers to trips. This needs to be changed in the database structure and in the frontend.

- The updating of miles_last on vehicles is handled on the application side, which is poor design imo, but mariaDB has a limitation with triggers to prevent infinite recursion that blocked my triggers, even though my triggers would not cause this recursion. There are a couple of ways that could fix this: 
    - Using stored procedures to do the update?
    - Maybe the triggers can be structured in such a way where they will not be blocked
    - Split up the vehicle table so that the triggers don't operate on the same tables
    - Something I'm not thinking about right now

- Cannot update the fuel level of vehicles after trips
    - frankly the fuel level should be set via a drop down or slider which gives fractional values (and the database would store them as close values eg. 1/8->13%)

# Things to do better next time:

- Use a better SQL library that allows for data to be directly translated into the programs data structures.
    - Could also use Pandas to convert the data. Either way I would be saving 200 LoC where I reinvented the wheel
    - sqlalchemy
    - 
- Use a better frontend. I found WxPython to be frustrating to work right easily. Small changes in layout or structure often required refactoring large amounts of code. Things that should work though the non-advanced interfaces just don't. Much of my time spent was trying to get the front end to play nicely. It made me into a copy-paste-catastrophe, since all the code to add a simple button or box is duplicated.
    - DJango
    - Flask
    - Pyramid
    - Bottle


# To run the program:

As a Binary: Nothing, it is fully self contained.

As a script: A configured development environment.


# To develop the program:
Python>=3.10

Python modules:

    mysql-connector-python>=8.3.0
    pyinstaller>=6.3.0
    wxPython>=4.2.1
    tabulate>=0.9.0

### Linux:
- To install wxpython:
	
	`$ pip install -U -f https://extras.wxpython.org/wxPython4/extras/linux/gtk3/ubuntu-22.04/ wxPython `

    Be sure to replace the URL with the one proper for your distribution. 
    
    The reasons for this odd installation are stated [here](https://wxpython.org/pages/downloads/index.html).

### Mac:
You'll need the command line developer tools:
- $ xcode-select --install

Add these directories to the PATH:
- /Users/{user}/Library/Python/{version}/bin

### Windows:
Depending on how python was installed, you may have to add directories to the PATH.

