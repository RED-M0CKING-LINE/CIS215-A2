from gui import window
from traceback import format_exc as traceback_format_exc


if __name__ == '__main__':
    try:
        window.main()
    except Exception as e:
        print("\nCATCHALL ERROR:\n{}".format(traceback_format_exc()))
    exit(0)

'''
def execute_command(command):
    print(command)
    return_code = call(command)
    print(return_code)
    return return_code
'''