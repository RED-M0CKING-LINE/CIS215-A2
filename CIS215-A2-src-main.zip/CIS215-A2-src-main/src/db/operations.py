from db.connection import DB_Connection
from wx import DateTime

class DB_Entry_Containers:
    person_keys = ['birth_date', 
            'driver_license_id', 
            'name_first', 
            'name_middle', 
            'name_last', 
            'address_street', 
            'address_city', 
            'address_state', 
            'address_country']
    def construct_entry_person(self,
                               birth_date=DateTime,
                               driver_license_id=None,
                                name_first=None,
                                name_middle=None,
                                name_last=None,
                                address_street=None,
                                address_city=None,
                                address_state=None,
                                address_country=None):
        return {
            self.person_keys[0]:str(birth_date.FormatISODate()),
            self.person_keys[1]:str(driver_license_id),
            self.person_keys[2]:str(name_first),
            self.person_keys[3]:str(name_middle),
            self.person_keys[4]:str(name_last),
            self.person_keys[5]:str(address_street),
            self.person_keys[6]:str(address_city),
            self.person_keys[7]:str(address_state),
            self.person_keys[8]:str(address_country)
        }

    vehicle_keys = ['oil_change_needed',
            'miles_oil_change_last',
            'miles_inital',
            'miles_last',
            'fuel_level',
            'license_plate',
            'condition_inital']
    def construct_entry_vehicle(self,
                                oil_change_needed=False,
                                miles_oil_change_last=0,
                                miles_initial=0,
                                miles_last=0,
                                fuel_level=0,
                                license_plate='',
                                condition_initial=''):
        return {
            self.vehicle_keys[0]: bool(oil_change_needed),
            self.vehicle_keys[1]: int(miles_oil_change_last),
            self.vehicle_keys[2]: int(miles_initial),
            self.vehicle_keys[3]: int(miles_last),
            self.vehicle_keys[4]: int(fuel_level),
            self.vehicle_keys[5]: str(license_plate),
            self.vehicle_keys[6]: str(condition_initial)
        }
        
    trip_keys = ['driver_id', 
            'vehicle_id', 
            'vehicle_milage_starting', 
            'vehicle_milage_ending', 
            'vehicle_condition_starting', 
            'vehicle_condition_ending', 
            'datetime_leave', 
            'datetime_arrival', 
            'datetime_returning', 
            'datetime_end', 
            'departure_street', 
            'departure_city', 
            'departure_state', 
            'departure_country', 
            'destination_street', 
            'destination_city', 
            'destination_state', 
            'destination_country', 
            'trip_reason', 
            'trip_issues']
    def construct_entry_trip(self,
                             driver_id=None,
                             vehicle_id=None,
                             vehicle_milage_starting=None,
                             vehicle_milage_ending=None,
                             vehicle_condition_starting=None,
                             vehicle_condition_ending=None,
                             datetime_leave=DateTime,
                             datetime_arrival=DateTime,
                             datetime_returning=DateTime,
                             datetime_end=DateTime,
                             departure_street=None,
                             departure_city=None,
                             departure_state=None,
                             departure_country=None,
                             destination_street=None,
                             destination_city=None,
                             destination_state=None,
                             destination_country=None,
                             trip_reason=None,
                             trip_issues=None): 
        return {
            self.trip_keys[0]:int(driver_id),
            self.trip_keys[1]:int(vehicle_id),
            self.trip_keys[2]:int(vehicle_milage_starting),
            self.trip_keys[3]:int(vehicle_milage_ending),
            self.trip_keys[4]:str(vehicle_condition_starting),
            self.trip_keys[5]:str(vehicle_condition_ending),
            self.trip_keys[6]:str(datetime_leave.FormatISOCombined()),
            self.trip_keys[7]:str(datetime_arrival.FormatISOCombined()),
            self.trip_keys[8]:str(datetime_returning.FormatISOCombined()),
            self.trip_keys[9]:str(datetime_end.FormatISOCombined()),
            self.trip_keys[10]:str(departure_street),
            self.trip_keys[11]:str(departure_city),
            self.trip_keys[12]:str(departure_state),
            self.trip_keys[13]:str(departure_country),
            self.trip_keys[14]:str(destination_street),
            self.trip_keys[15]:str(destination_city),
            self.trip_keys[16]:str(destination_state),
            self.trip_keys[17]:str(destination_country),
            self.trip_keys[18]:str(trip_reason),
            self.trip_keys[19]:str(trip_issues)
        }

class DB_Operations:
    def __init__(self) -> None:
        self.db = DB_Connection()
        self.containers = DB_Entry_Containers()
    
    def person_create(self, entry:dict):
        query = 'INSERT INTO person ('
        query_values = ') VALUES ('
        first_value = True
        for key, value in entry.items():
            if not first_value:
                query += ', '
                query_values += ', '
            query += str(key)
            query_values += '%s'
            first_value = False
        query += query_values + ');'
        return self.db.query(query, [entry[key] for key in self.containers.person_keys])
    
    def person_lookup(self, drivers_license_id:str):
        query = self.db.query("SELECT id FROM person WHERE driver_license_id = %s LIMIT 1;", [drivers_license_id])
        try:
            return query.get('results')[0][0]
        except IndexError as e:
            return None
        
    def trip_create(self, entry:dict):
        query = 'INSERT INTO trip ('
        query_values = ') VALUES ('
        first_value = True
        for key, value in entry.items():
            if not first_value:
                query += ', '
                query_values += ', '
            query += str(key)
            query_values += '%s'
            first_value = False
        query += query_values + ');'
        self.db.query('UPDATE vehicle SET miles_last = %s WHERE id = %s;', [entry['vehicle_milage_ending'], entry['vehicle_id']]) #TODO this doesnt work due to the trigger, somehow make it update the vehicle.miles_last with the trip.vehicle_milage_ending
        return self.db.query(query, [entry[key] for key in self.containers.trip_keys])
    
    def vehicle_create(self, entry:dict):
        query = 'INSERT INTO vehicle ('
        query_values = ') VALUES ('
        first_value = True
        for key, value in entry.items():
            if not first_value:
                query += ', '
                query_values += ', '
            query += str(key)
            query_values += '%s'
            first_value = False
        query += query_values + ');'
        return self.db.query(query, [entry[key] for key in self.containers.vehicle_keys])
    
    def vehicle_lookup(self, license_plate:str): #TODO IMPLEMENT THIS METHOD
        query = self.db.query("SELECT id FROM vehicle WHERE license_plate = %s LIMIT 1;", [license_plate])
        try:
            return query.get('results')[0][0]
        except IndexError as e:
            return None
        
    def search(self, tbl, key=None, val=None):
        if key is None or val is None:
            query = self.db.query("SELECT * FROM {};".format(tbl))
        else:
            query = self.db.query("SELECT * FROM {} WHERE {} = %s;".format(tbl, key), [val])
        return query
    
    
    
    
db_operations = DB_Operations()