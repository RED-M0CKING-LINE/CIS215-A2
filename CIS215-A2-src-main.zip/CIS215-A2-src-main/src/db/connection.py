from sqlite3 import IntegrityError
import mysql.connector
from tabulate import tabulate

class DB_Connection:
    def __init__(self):
        # Storing the connection information in the code is out of laziness and bad practice. Never do this except for testing purposes.
        try:
            self.myDB = mysql.connector.connect(
                host='192.168.56.101',
                user='user',
                password='password',
                database='FUN',
                connect_timeout=1
            )
        except mysql.connector.Error as e:
            print("Error connecting to database:", e)

    def getConnection(self) -> mysql.connector:
        return self.myDB if hasattr(self, 'myDB') else None
    
    def test(self):
        self.queryAndShow("SHOW DATABASES")

    def query(self, command:str, values=None):
        if(self.getConnection() is None): return None
        if values is not None:
            for index, value in enumerate(values):
                if value == '':
                    values[index] = None
        print(command, values)
        cursor = self.myDB.cursor(buffered=True)
        try:
            cursor.execute(command, values)
        except mysql.connector.errors.IntegrityError as e:
            print("Error executing SQL command:", e)
            return {'error':e}
        self.myDB.commit()
        results = cursor.fetchall() if cursor.description else None
        return {'error':None, 'warnings':cursor.fetchwarnings(), 'rows_affected':cursor.rowcount, 'headers':cursor.description, 'results':results}

    # THIS IS MOSTLY FOR DEBUGGING PURPOSES
    def queryAndShow(self, command, values=None, rowsToShow=10):
        print("Sending SQL Command: {}".format(command))
        cursor = self.myDB.cursor(buffered=True)
        cursor.execute(command)
        self.myDB.commit()
        print("Command Results:\n\tWarnings: {}\n\tRows Affected: {}".format(cursor.fetchwarnings(), cursor.rowcount()))
        print("\t" + tabulate(cursor.fetchmany(rowsToShow), tablefmt='grid').replace("\n", "\n\t"))
        try:
            cursor.close()
        except mysql.connector.errors.InternalError as e:
            if e.msg == 'Unread result found':
                print("\t-----CUT-----")
                cursor.reset()
                cursor.close()
            else:
                raise
        
            
        