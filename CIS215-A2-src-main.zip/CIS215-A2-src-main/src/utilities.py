import wx

def combine_wx_date_time(date:wx.DateTime, time:wx.DateTime):
    return wx.DateTime(year=date.GetYear(), 
                       month=date.GetMonth(), 
                       day=date.GetDay(), 
                       hour=time.GetHour(), 
                       minute=time.GetMinute(), 
                       second=time.GetSecond(), 
                       millisec=time.GetMillisecond())

