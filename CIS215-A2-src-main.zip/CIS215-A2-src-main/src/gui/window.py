from gui.tabs import person_create, tab_1, vehicle_create, trip_log, search
import wx
import wx.adv

class Frame(wx.Frame):    
    def __init__(self):
        super().__init__(parent=None, title='CIS215 A2', name='CIS215 A2', size=(1000, 1100), style=wx.DEFAULT_FRAME_STYLE)
        
        # Allows the contents in the frame to be scrolled
        # Another way to achieve this would be to place the scrolled window into the tabs, that way the tabs stay on top
        # I am not doing that right now. Its far too cumbersome
        self.window_scrolled = wx.ScrolledWindow(self, style=wx.VSCROLL)
        self.window_scrolled.SetScrollRate(10, 10)
        
        self.notebook = wx.Notebook(self.window_scrolled)
        self.notebook.AddPage(person_create.Person_Create(self.notebook), "Create Person")
        self.notebook.AddPage(vehicle_create.Vehicle_Create(self.notebook), "Create Vehicle")
        self.notebook.AddPage(trip_log.Trip_Log(self.notebook), "Log Trip")
        self.notebook.AddPage(search.Search(self.notebook), "Search")
        # self.notebook.AddPage(tab_1.Tab_1(self.notebook), "Tab_1")
        
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.notebook, proportion=1, flag=wx.EXPAND)
        self.window_scrolled.SetSizerAndFit(self.sizer)

        # Configure and show the frame
        self.CenterOnScreen()
        self.Show()
        self.Raise()
        
      
    '''
    def popup(self, title,  message):
        wx.MessageBox(message=message, caption=title, style=wx.CENTER|wx.STAY_ON_TOP|wx.OK)
    '''

##############################


def main():
    app = wx.App()
    frame = Frame()
    app.SetTopWindow(frame)
    app.MainLoop()