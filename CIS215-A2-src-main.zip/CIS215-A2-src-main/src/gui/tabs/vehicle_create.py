import wx
import wx.adv
from wx.lib.intctrl import IntCtrl
from db.operations import DB_Entry_Containers, db_operations


class Vehicle_Create(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)
        
        # License Plate
        license_plate_text = wx.StaticText(self, label="License Plate: ")
        self.license_plate = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.sizer_license = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_license.Add(license_plate_text, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_license.Add(self.license_plate)
        
        # Mileage
        mileage_text = wx.StaticText(self, label="Mileage: ")
        self.mileage = IntCtrl(self, style=wx.TE_LEFT, min=0, allow_none=True, value=None)
        self.sizer_mileage = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_mileage.Add(mileage_text, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_mileage.Add(self.mileage)
        
        # Miles at last oil change
        oil_change_mileage_text = wx.StaticText(self, label="Mileage at last oil change: ")
        self.oil_change_mileage = IntCtrl(self, style=wx.TE_LEFT, min=0, allow_none=True, value=None)
        self.sizer_oil_change_mileage = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_oil_change_mileage.Add(oil_change_mileage_text, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_oil_change_mileage.Add(self.oil_change_mileage)
        
        # Fuel Level
        fuel_level_text = wx.StaticText(self, label="Fuel Level: ")
        fuel_level_text_unit = wx.StaticText(self, label="%")
        self.fuel_level = IntCtrl(self, style=wx.TE_LEFT, min=0, max=100, allow_none=True, value=None)
        self.sizer_fuel_level = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_fuel_level.Add(fuel_level_text, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_fuel_level.Add(self.fuel_level)
        self.sizer_fuel_level.Add(fuel_level_text_unit, flag=wx.ALIGN_CENTER_VERTICAL)
        
        condition_desc_text = wx.StaticText(self, label="Condition Description: ")
        self.condition_desc = wx.TextCtrl(self, style=wx.TE_LEFT|wx.TE_MULTILINE|wx.TE_BESTWRAP)
        
        # Submit button and status
        self.btn_submit = wx.Button(self, label='Create')
        self.btn_submit.Bind(wx.EVT_BUTTON, self.btn_submit_event)
        self.status_text = wx.StaticText(self, label="")
        self.sizer_bottom = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_bottom.Add(self.status_text, border=5, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_bottom.AddStretchSpacer()
        self.sizer_bottom.Add(self.btn_submit, border=5, flag=wx.ALL)
        
        # Place things onto the main sizer
        sizer_main = wx.BoxSizer(wx.VERTICAL)
        sizer_main.Add(self.sizer_license, border=20)
        sizer_main.Add(self.sizer_mileage, border=20)
        sizer_main.Add(self.sizer_oil_change_mileage, border=20)
        sizer_main.Add(self.sizer_fuel_level, border=20)
        sizer_main.Add(condition_desc_text, border=20)
        sizer_main.Add(self.condition_desc, border=5, proportion=1, flag=wx.EXPAND|wx.ALL)
        sizer_main.Add(self.sizer_bottom, border=5, flag=wx.EXPAND|wx.ALL)
        self.SetSizerAndFit(sizer_main)
        
        
    def btn_submit_event(self, event):
        
        result = db_operations.vehicle_create(db_operations.containers.construct_entry_vehicle(
                oil_change_needed=False,
                miles_oil_change_last=self.oil_change_mileage.GetValue(),
                miles_initial=self.oil_change_mileage.GetValue(),
                miles_last=self.mileage.GetValue(),
                fuel_level=self.fuel_level.GetValue(),
                license_plate=self.license_plate.GetValue(),
                condition_initial=self.condition_desc.GetValue()))
        if result is None:
            self.status_text.SetLabel('FAIL: No Connection to server')
        elif result['error'] is not None:
            self.status_text.SetLabel('FAIL: ' + str(result['error']))
        elif result['warnings'] is None:
            self.status_text.SetLabel("SUCCESS!")
        else:
            self.status_text.SetLabel('FAIL: ' + str(result['warnings']))
        
        self.status_text.SetLabel("SUCCESS!")

    
