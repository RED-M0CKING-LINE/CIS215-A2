import wx
import wx.adv
from wx.lib.intctrl import IntCtrl
from db.operations import DB_Entry_Containers, db_operations
from utilities import combine_wx_date_time

class Trip_Log(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)
        
        # Create the labels and text controls for each input field
        driver_id_label = wx.StaticText(self, label="Driver's Drivers License ID:")
        self.driver_id_text = wx.TextCtrl(self)

        plate_number_label = wx.StaticText(self, label="Vehicle Plate Number:")
        self.plate_number_text = wx.TextCtrl(self)

        leaving_sizer = wx.BoxSizer(wx.HORIZONTAL)
        leaving_label = wx.StaticText(self, label="Date and Time for Leaving:", style=wx.ALIGN_CENTER_VERTICAL)
        self.leaving_date = wx.adv.DatePickerCtrl(self)
        self.leaving_time = wx.adv.TimePickerCtrl(self)
        leaving_sizer.Add(leaving_label)
        leaving_sizer.Add(self.leaving_date)
        leaving_sizer.Add(self.leaving_time)

        arrival_sizer = wx.BoxSizer(wx.HORIZONTAL)
        arrival_label = wx.StaticText(self, label="Date and Time for Arrival:", style=wx.ALIGN_CENTER_VERTICAL)
        self.arrival_date = wx.adv.DatePickerCtrl(self)
        self.arrival_time = wx.adv.TimePickerCtrl(self)
        arrival_sizer.Add(arrival_label)
        arrival_sizer.Add(self.arrival_date)
        arrival_sizer.Add(self.arrival_time)

        returning_sizer = wx.BoxSizer(wx.HORIZONTAL)
        returning_label = wx.StaticText(self, label="Date and Time for Returning:", style=wx.ALIGN_CENTER_VERTICAL)
        self.returning_date = wx.adv.DatePickerCtrl(self)
        self.returning_time = wx.adv.TimePickerCtrl(self)
        returning_sizer.Add(returning_label)
        returning_sizer.Add(self.returning_date)
        returning_sizer.Add(self.returning_time)

        ending_sizer = wx.BoxSizer(wx.HORIZONTAL)
        ending_label = wx.StaticText(self, label="Date and Time for Ending:", style=wx.ALIGN_CENTER_VERTICAL)
        self.ending_date = wx.adv.DatePickerCtrl(self)
        self.ending_time = wx.adv.TimePickerCtrl(self)
        ending_sizer.Add(ending_label)
        ending_sizer.Add(self.ending_date)
        ending_sizer.Add(self.ending_time)

        # Departure Address
        address_depart_text = wx.StaticText(self, label="Departure Address")
        self.address_depart_street = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_depart_street.SetHint('Street')
        self.address_depart_city = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_depart_city.SetHint('City')
        sizer_address_depart_1 = wx.BoxSizer(wx.HORIZONTAL)
        sizer_address_depart_1.Add(self.address_depart_street, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_address_depart_1.Add(self.address_depart_city, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        self.address_depart_state = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_depart_state.SetHint('State')
        self.address_depart_country = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_depart_country.SetHint('Country')
        sizer_address_depart_2 = wx.BoxSizer(wx.HORIZONTAL)
        sizer_address_depart_2.Add(self.address_depart_state, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_address_depart_2.Add(self.address_depart_country, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        
        # Destination Address
        address_dest_text = wx.StaticText(self, label="Destination Address")
        self.address_dest_street = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_dest_street.SetHint('Street')
        self.address_dest_city = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_dest_city.SetHint('City')
        sizer_address_dest_1 = wx.BoxSizer(wx.HORIZONTAL)
        sizer_address_dest_1.Add(self.address_dest_street, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_address_dest_1.Add(self.address_dest_city, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        self.address_dest_state = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_dest_state.SetHint('State')
        self.address_dest_country = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_dest_country.SetHint('Country')
        sizer_address_dest_2 = wx.BoxSizer(wx.HORIZONTAL)
        sizer_address_dest_2.Add(self.address_dest_state, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_address_dest_2.Add(self.address_dest_country, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)

        starting_mileage_label = wx.StaticText(self, label="Mileage Starting:")
        self.starting_mileage_text = IntCtrl(self, min=0, allow_none=True, value=None)

        ending_mileage_label = wx.StaticText(self, label="Mileage Ending:")
        self.ending_mileage_text = IntCtrl(self, min=0, allow_none=True, value=None)

        starting_condition_label = wx.StaticText(self, label="Vehicle Starting Condition:")
        self.starting_condition_text = wx.TextCtrl(self, style=wx.TE_MULTILINE)

        ending_condition_label = wx.StaticText(self, label="Vehicle Ending Condition:")
        self.ending_condition_text = wx.TextCtrl(self, style=wx.TE_MULTILINE)

        reason_label = wx.StaticText(self, label="Reason for Taking the Trip:")
        self.reason_text = wx.TextCtrl(self, style=wx.TE_MULTILINE)

        issues_label = wx.StaticText(self, label="Issues During the Trip:")
        self.issues_text = wx.TextCtrl(self, style=wx.TE_MULTILINE)
        
        # Submit button and status
        self.btn_submit = wx.Button(self, label='Create')
        self.btn_submit.Bind(wx.EVT_BUTTON, self.btn_submit_event)
        self.status_text = wx.StaticText(self, label="")
        self.sizer_bottom = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_bottom.Add(self.status_text, border=5, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_bottom.AddStretchSpacer()
        self.sizer_bottom.Add(self.btn_submit, border=5, flag=wx.ALL)

        # Create a sizer to arrange the controls vertically
        sizer_main = wx.BoxSizer(wx.VERTICAL)
        sizer_main.Add(driver_id_label, 0, wx.ALL, 5)
        sizer_main.Add(self.driver_id_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(plate_number_label, 0, wx.ALL, 5)
        sizer_main.Add(self.plate_number_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(leaving_sizer, 0, wx.ALL, 5)
        sizer_main.Add(arrival_sizer, 0, wx.ALL, 5)
        sizer_main.Add(returning_sizer, 0, wx.ALL, 5)
        sizer_main.Add(ending_sizer, 0, wx.ALL, 5)
        sizer_main.Add(address_depart_text, 0, wx.CENTER)
        sizer_main.Add(sizer_address_depart_1, 0, wx.EXPAND, 20)
        sizer_main.Add(sizer_address_depart_2, 0, wx.EXPAND, 20)
        sizer_main.Add(address_dest_text, 0, wx.CENTER)
        sizer_main.Add(sizer_address_dest_1, 0, wx.EXPAND, 20)
        sizer_main.Add(sizer_address_dest_2, 0, wx.EXPAND, 20)
        sizer_main.Add(starting_mileage_label, 0, wx.ALL, 5)
        sizer_main.Add(self.starting_mileage_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(ending_mileage_label, 0, wx.ALL, 5)
        sizer_main.Add(self.ending_mileage_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(starting_condition_label, 0, wx.ALL, 5)
        sizer_main.Add(self.starting_condition_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(ending_condition_label, 0, wx.ALL, 5)
        sizer_main.Add(self.ending_condition_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(reason_label, 0, wx.ALL, 5)
        sizer_main.Add(self.reason_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.Add(issues_label, 0, wx.ALL, 5)
        sizer_main.Add(self.issues_text, 0, wx.EXPAND|wx.ALL, 5)
        sizer_main.AddStretchSpacer()
        sizer_main.Add(self.sizer_bottom, 0, wx.EXPAND|wx.ALL, 0)

        self.SetSizer(sizer_main)

    def btn_submit_event(self, event):
        driver_id = db_operations.person_lookup(self.driver_id_text.GetValue())
        if driver_id is None:
            self.status_text.SetLabel('FAIL: No such driver found.')
            return False
        
        vehicle_id = db_operations.vehicle_lookup(self.plate_number_text.GetValue())
        if vehicle_id is None:
            self.status_text.SetLabel('FAIL: No such vehicle found.')
            return False
        
        leaving_datetime = combine_wx_date_time(self.leaving_date.GetValue(),self.leaving_time.GetValue())
        arrival_datetime = combine_wx_date_time(self.arrival_date.GetValue(),self.arrival_time.GetValue())
        returning_datetime = combine_wx_date_time(self.returning_date.GetValue(),self.returning_time.GetValue())
        ending_datetime = combine_wx_date_time(self.ending_date.GetValue(),self.ending_time.GetValue())
        
        result = db_operations.trip_create(db_operations.containers.construct_entry_trip(
                    driver_id=driver_id,
                    vehicle_id=vehicle_id,
                    vehicle_milage_starting=self.starting_mileage_text.GetValue(),
                    vehicle_milage_ending=self.ending_mileage_text.GetValue(),
                    vehicle_condition_starting=self.starting_condition_text.GetValue(),
                    vehicle_condition_ending=self.ending_condition_text.GetValue(),
                    datetime_leave=leaving_datetime,
                    datetime_arrival=arrival_datetime,
                    datetime_returning=returning_datetime,
                    datetime_end=ending_datetime,
                    departure_street=self.address_depart_street.GetValue(),
                    departure_city=self.address_depart_city.GetValue(),
                    departure_state=self.address_depart_state.GetValue(),
                    departure_country=self.address_depart_country.GetValue(),
                    destination_street=self.address_dest_street.GetValue(),
                    destination_city=self.address_dest_city.GetValue(),
                    destination_state=self.address_dest_state.GetValue(),
                    destination_country=self.address_dest_country.GetValue(),
                    trip_reason=self.reason_text.GetValue(),
                    trip_issues=self.issues_text.GetValue()))
        
        if result is None:
            self.status_text.SetLabel('FAIL: No Connection to server')
        elif result['error'] is not None:
            self.status_text.SetLabel('FAIL: ' + str(result['error']))
        elif result['warnings'] is None:
            self.status_text.SetLabel("SUCCESS!")
        else:
            self.status_text.SetLabel('FAIL: ' + str(result['warnings']))
