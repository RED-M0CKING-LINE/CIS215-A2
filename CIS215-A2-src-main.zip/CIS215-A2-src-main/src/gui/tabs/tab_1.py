import wx
import wx.adv

from db.operations import DB_Operations

class Tab_1(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        # Setup input for room number
        sizer_room = wx.BoxSizer(wx.VERTICAL)
        room_input_text = wx.StaticText(self, label="Room Number")
        sizer_room.Add(room_input_text, flag=wx.ALL|wx.LEFT, border=2)
        self.room_input = wx.TextCtrl(self, size=(120, 40), style=wx.TE_LEFT|wx.TE_MULTILINE)
        sizer_room.Add(self.room_input, flag=wx.ALL|wx.LEFT, border=2)
        
        # Setup the date selector
        self.date_selector = wx.adv.DatePickerCtrl(self)

        # TESTING BUTTON
        btn_test = wx.Button(self, label='TEST')
        btn_test.Bind(wx.EVT_BUTTON, self.btn_test_on_press)
        
        # Setup okay and cancel buttons buttons
        sizer_btn_1 = wx.BoxSizer(wx.HORIZONTAL)
        btn_cancel = wx.Button(self, label='Cancel')
        btn_cancel.Bind(wx.EVT_BUTTON, self.btn_cancel_on_press)
        sizer_btn_1.Add(btn_cancel, flag=wx.ALL|wx.LEFT)
        sizer_btn_1.AddStretchSpacer()
        btn_okay = wx.Button(self, label='Okay')
        btn_okay.Bind(wx.EVT_BUTTON, self.btn_okay_on_press)
        sizer_btn_1.Add(btn_okay, flag=wx.ALL|wx.RIGHT)

        # Place things on the main sizer
        sizer_main = wx.BoxSizer(wx.VERTICAL)
        sizer_main.Add(sizer_room, flag=wx.EXPAND|wx.ALL, border=1)
        sizer_main.Add(self.date_selector, flag=wx.ALL|wx.LEFT, border=2)
        sizer_main.Add(btn_test, flag=wx.EXPAND|wx.ALL, border=10)
        sizer_main.AddStretchSpacer()
        sizer_main.Add(sizer_btn_1, flag=wx.EXPAND|wx.ALL, border=5)
        self.SetSizerAndFit(sizer_main)

    def btn_okay_on_press(self, event):
        print(self.date_selector.GetValue().Format("%Y-%m-%d"))
        keep_going = True
        percent_complete = 0
        dlg_progress = wx.ProgressDialog("Simple Progress Dialog", "Progress...", maximum=100, parent=self, style=wx.PD_APP_MODAL|wx.PD_CAN_ABORT|wx.PD_AUTO_HIDE)
        
        while keep_going and percent_complete < 100:
            percent_complete += 10
            wx.MilliSleep(400) # Would call functions and update after operations
            keep_going = dlg_progress.Update(percent_complete, "Progress: {}".format(percent_complete))

        dlg_progress.Destroy()
        
    def btn_cancel_on_press(self, event):
        self.GetTopLevelParent().Close()
        
    def btn_test_on_press(self, event):
        db_operations = DB_Operations()
        result = db_operations.person_create(
                                    self.date_selector.GetValue(),
                                    "ID2376827349",
                                    "FName",
                                    "MName",
                                    "LName",
                                    "aStreet",
                                    "aCity",
                                    "aState",
                                    "aCountry")
        print(result)