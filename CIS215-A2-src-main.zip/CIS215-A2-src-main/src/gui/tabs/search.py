import wx
import wx.adv
import wx.grid
from db.operations import DB_Entry_Containers, db_operations

class Search(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)
        
        sizer_input = wx.BoxSizer(wx.HORIZONTAL)
        self.choice_category = wx.Choice(self, choices=['Person', 'Vehicle', 'Trip'])
        self.choice_category.Bind(wx.EVT_CHOICE, self.update_dropdown_options)
        sizer_input.Add(self.choice_category, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)
        self.choice_dropdown = wx.Choice(self)
        sizer_input.Add(self.choice_dropdown, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)
        self.text_input = wx.TextCtrl(self, style=wx.TE_PROCESS_ENTER)
        self.text_input.SetHint("Enter value to search for...")
        self.text_input.Bind(wx.EVT_TEXT_ENTER, self.btn_submit_event)
        sizer_input.Add(self.text_input, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5)
        self.btn_submit = wx.Button(self, label='Search')
        self.btn_submit.Bind(wx.EVT_BUTTON, self.btn_submit_event)
        sizer_input.Add(self.btn_submit, 0, wx.ALL, 5)
        self.btn_get_all = wx.Button(self, label='Get All')
        self.btn_get_all.Bind(wx.EVT_BUTTON, self.btn_get_all_event)
        sizer_input.Add(self.btn_get_all, 0, wx.ALL, 5)

        self.grid = wx.grid.Grid(self)
        self.grid.CreateGrid(0,26)
        
        
        # Submit button and status
        self.status_text = wx.StaticText(self, label="")
        
        # Place things onto the main sizer
        sizer_main = wx.BoxSizer(wx.VERTICAL)
        sizer_main.Add(sizer_input, 0, wx.EXPAND|wx.ALL, 10)
        sizer_main.Add(self.grid, 1, wx.EXPAND|wx.ALL, 20,)
        sizer_main.Add(self.status_text, 0, wx.EXPAND|wx.ALL, 0)
        self.SetSizerAndFit(sizer_main)
        
    def btn_submit_event(self, event):
        if self.choice_category.GetStringSelection() == '' or self.choice_dropdown.GetStringSelection() == '':
            self.status_text.SetLabel('FAIL: No category selected')
            return
        elif self.text_input.GetValue() == '':
            self.status_text.SetLabel('FAIL: No value entered')
            return
        
        result = db_operations.search(self.choice_category.GetStringSelection().lower(), self.choice_dropdown.GetStringSelection(), self.text_input.GetValue())
        if result is None:
            self.status_text.SetLabel('FAIL: No Connection to server')
            return
        elif result['error'] is not None:
            self.status_text.SetLabel('FAIL: ' + str(result['error']))
            return
        elif result['warnings'] is None:
            self.status_text.SetLabel("SUCCESS!")
        else:
            self.status_text.SetLabel('FAIL: ' + str(result['warnings']))
            return
        
        self.grid.ClearGrid()
        if self.grid.GetNumberRows() > 0:
            self.grid.DeleteRows(0, self.grid.GetNumberRows())
        
        for i, header in enumerate(result['headers']):
            self.grid.SetColLabelValue(i, str(header[0]))
            
        for row, entry in enumerate(result['results']):
            self.grid.AppendRows()
            for i in range(len(entry)):
                self.grid.SetCellValue(row, i, str(entry[i]))
            
        self.grid.AutoSizeColumns()
    
    def btn_get_all_event(self, event):
        if self.choice_category.GetStringSelection() == '':
            self.status_text.SetLabel('FAIL: No category selected')
            return
        
        result = db_operations.search(self.choice_category.GetStringSelection().lower())
        if result['error'] is not None:
            self.status_text.SetLabel('FAIL: ' + str(result['error']))
            return
        elif result is None:
            self.status_text.SetLabel('FAIL: No Connection to server')
            return
        elif result['warnings'] is None:
            self.status_text.SetLabel("SUCCESS!")
        else:
            self.status_text.SetLabel('FAIL: ' + str(result['warnings']))
            return
        
        self.grid.ClearGrid()
        if self.grid.GetNumberRows() > 0:
            self.grid.DeleteRows(0, self.grid.GetNumberRows())
        
        for i, header in enumerate(result['headers']):
            self.grid.SetColLabelValue(i, str(header[0]))
            
        for row, entry in enumerate(result['results']):
            self.grid.AppendRows()
            for i in range(len(entry)):
                self.grid.SetCellValue(row, i, str(entry[i]))
            
        self.grid.AutoSizeColumns()
    
    def update_dropdown_options(self, event):
        selected_category = self.choice_category.GetStringSelection()
        if selected_category == 'Person':
            choices = db_operations.containers.person_keys
        elif selected_category == 'Vehicle':
            choices = db_operations.containers.vehicle_keys
        elif selected_category == 'Trip':
            choices = db_operations.containers.trip_keys
        else:
            choices = []
        self.choice_dropdown.Set(choices)
