import wx
import wx.adv
from db.operations import DB_Entry_Containers, db_operations

class Person_Create(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)

        # Name
        name_text = wx.StaticText(self, label="Name")
        self.name_first = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.name_first.SetHint('First Name')
        self.name_middle = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.name_middle.SetHint('Middle Name')
        self.name_last = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.name_last.SetHint('Last Name')
        sizer_name = wx.BoxSizer(wx.HORIZONTAL)
        sizer_name.Add(self.name_first, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_name.Add(self.name_middle, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_name.Add(self.name_last, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        
        # Birthday  
        birthday_text = wx.StaticText(self, label="Date of Birth: ")
        self.birthday_date = wx.adv.DatePickerCtrl(self)
        sizer_birthday = wx.BoxSizer(wx.HORIZONTAL)
        sizer_birthday.Add(birthday_text, flag=wx.ALIGN_CENTER_VERTICAL)
        sizer_birthday.Add(self.birthday_date)
        
        # Address
        address_text = wx.StaticText(self, label="Address")
        self.address_street = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_street.SetHint('Street')
        self.address_city = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_city.SetHint('City')
        sizer_address_1 = wx.BoxSizer(wx.HORIZONTAL)
        sizer_address_1.Add(self.address_street, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_address_1.Add(self.address_city, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        self.address_state = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_state.SetHint('State')
        self.address_country = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.address_country.SetHint('Country')
        sizer_address_2 = wx.BoxSizer(wx.HORIZONTAL)
        sizer_address_2.Add(self.address_state, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        sizer_address_2.Add(self.address_country, proportion=1, flag=wx.EXPAND|wx.ALL, border=5)
        
        # Driver
        self.driver_checkbox = wx.CheckBox(self, label=' Can this person drive?')
        self.driver_checkbox.Bind(wx.EVT_CHECKBOX, self.driver_checkbox_event)

        # License ID
        license_text = wx.StaticText(self, label="Drivers License ID: ")
        self.license_id = wx.TextCtrl(self, style=wx.TE_LEFT)
        self.sizer_license = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_license.Add(license_text, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_license.Add(self.license_id)
        
        # Submit button and status
        self.btn_submit = wx.Button(self, label='Create')
        self.btn_submit.Bind(wx.EVT_BUTTON, self.btn_submit_event)
        self.status_text = wx.StaticText(self, label="")
        self.sizer_bottom = wx.BoxSizer(wx.HORIZONTAL)
        self.sizer_bottom.Add(self.status_text, border=5, flag=wx.ALIGN_CENTER_VERTICAL)
        self.sizer_bottom.AddStretchSpacer()
        self.sizer_bottom.Add(self.btn_submit, border=5, flag=wx.ALL)
        
        # Place things onto the main sizer
        sizer_main = wx.BoxSizer(wx.VERTICAL)
        sizer_main.Add(name_text, 0, wx.CENTER)
        sizer_main.Add(sizer_name, 0, wx.EXPAND, 20)
        sizer_main.AddSpacer(size=15)
        sizer_main.Add(sizer_birthday, 0, border=20)
        sizer_main.AddSpacer(size=15)
        sizer_main.Add(address_text, 0, wx.CENTER)
        sizer_main.Add(sizer_address_1, 0, wx.EXPAND, 20)
        sizer_main.Add(sizer_address_2, 0, wx.EXPAND, 20)
        sizer_main.AddSpacer(size=15)
        sizer_main.Add(self.driver_checkbox, 0, border=20)
        sizer_main.Add(self.sizer_license, 0, border=20)
        sizer_main.AddStretchSpacer()
        sizer_main.Add(self.sizer_bottom, 0, wx.EXPAND|wx.ALL, 0)
        self.SetSizerAndFit(sizer_main)
        
        # Hide license by default 
        self.sizer_license.ShowItems(False)
        
    def btn_submit_event(self, event):
        result = db_operations.person_create(db_operations.containers.construct_entry_person(
                    birth_date=self.birthday_date.GetValue(),
                    driver_license_id=self.license_id.GetValue(),
                    name_first=self.name_first.GetValue(),
                    name_middle=self.name_middle.GetValue(),
                    name_last=self.name_last.GetValue(),
                    address_street=self.address_street.GetValue(),
                    address_city=self.address_city.GetValue(),
                    address_state=self.address_state.GetValue(),
                    address_country=self.address_country.GetValue()))
        
        if result is None:
            self.status_text.SetLabel('FAIL: No Connection to server')
        elif result['error'] is not None:
            self.status_text.SetLabel('FAIL: ' + str(result['error']))
        elif result['warnings'] is None:
            self.status_text.SetLabel("SUCCESS!")
        else:
            self.status_text.SetLabel('FAIL: ' + str(result['warnings']))
    
    def driver_checkbox_event(self, event):
        if self.driver_checkbox.IsChecked():
            self.sizer_license.ShowItems(True)
        else:
            self.sizer_license.ShowItems(False)
            self.license_id.SetValue('')
