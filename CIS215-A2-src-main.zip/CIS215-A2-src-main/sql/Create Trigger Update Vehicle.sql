CREATE TRIGGER update_vehicle_miles
BEFORE INSERT ON trip
FOR EACH ROW
BEGIN
   UPDATE vehicle
   SET miles_last = NEW.vehicle_milage_ending
   WHERE id = NEW.vehicle_id;
END;

-- TODO THIS DIDNT WORK SO FIND SOMETHING ELSE