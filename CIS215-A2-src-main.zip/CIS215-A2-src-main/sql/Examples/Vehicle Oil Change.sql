UPDATE vehicle 
SET miles_oil_change_last = 200000
WHERE id = 8;
