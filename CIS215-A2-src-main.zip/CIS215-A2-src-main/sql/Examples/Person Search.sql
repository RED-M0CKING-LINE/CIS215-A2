SELECT * 
FROM person 
WHERE name_first = 'John' AND name_last = 'Doe';
-- WHERE driver_license_id = 'A12345678';
