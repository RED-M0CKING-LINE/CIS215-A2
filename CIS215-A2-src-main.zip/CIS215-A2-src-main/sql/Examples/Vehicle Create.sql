INSERT INTO vehicle (
	             oil_change_needed,
	             miles_oil_change_last,
	             miles_inital,
	             miles_last,
	             fuel_level,
	             license_plate,
	             condition_inital) 
VALUES (False, 
        1234, 
        1234, 
        1234, 
        20, 
        'edlg3956', 
        'mighty');
