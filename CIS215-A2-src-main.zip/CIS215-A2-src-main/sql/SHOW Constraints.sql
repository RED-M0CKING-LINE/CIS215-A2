SELECT *
FROM information_schema.table_constraints
WHERE constraint_schema = 'FUN'
