python3 -O -m PyInstaller \
--onefile \
--noconfirm \
--clean \
--noconsole \
--icon icon.icns \
./src/CIS215A2.py
